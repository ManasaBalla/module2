package com.cg.cma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.cma.dto.Course;
import com.cg.cma.exceptions.CourseException;

public class CourseDaoImpl implements CourseDao {
	Connection conn;
	
	private long generateCourseId() throws CourseException{
		conn = DBUtil.getConnection();
		String sql = "SELECT seq_course_id.NEXTVAL FROM DUAL";
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			rst.next();
			return rst.getLong(1);
		} catch (SQLException e) {
			throw new CourseException("Problem in generating course id "
										+e.getMessage());
		}
	}
	@Override
	public long insertCourse(Course course) throws CourseException {
		String sql = "INSERT INTO course VALUES(?,?,?,?)";
		course.setCourseId(generateCourseId());
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setLong(1, course.getCourseId());
			pst.setString(2, course.getCourseTitle());
			pst.setDouble(3, course.getFees());
			pst.setInt(4, course.getDuration());
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new CourseException("Problem in inserting the details "
							+e.getMessage());
		}
		return course.getCourseId();
	}
	@Override
	public List<Course> getAllCourses() throws CourseException {
		String sql = "SELECT course_id, course_title, fees, duration FROM course";
		ArrayList<Course> clist = new ArrayList<>();
		conn = DBUtil.getConnection();
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			while(rst.next()) {
				Course c = new Course();
				c.setCourseId(rst.getLong("course_id"));
				c.setCourseTitle(rst.getString("course_title"));
				c.setFees(rst.getDouble("fees"));
				c.setDuration(rst.getInt("duration"));
				clist.add(c);
			}
		} catch (SQLException e) {
			throw new CourseException("Problem in fetching the details "+e.getMessage());
		}
		return clist;
	}

	@Override
	public boolean updateCourse(Course course) throws CourseException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCourse(long courseid) throws CourseException {
		// TODO Auto-generated method stub
		return false;
	}

}
