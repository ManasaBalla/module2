package cm.cg.cra.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;

import com.cg.cra.dao.RegistrationDao;
import com.cg.cra.dao.RegistrationDaoImpl;
import com.cg.cra.dto.Registration;
import com.cg.cra.exceptions.RegistrationException;

public class RegistrationTester {

	RegistrationDao rdao;
	@Before
	public void beforeMethod(){
		rdao = new RegistrationDaoImpl();
	}
	
	@Test
	public void testValidateCourseId() {
		  try {
			 assertTrue(rdao.validateCourseId(1));
		} catch (RegistrationException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testRegister() {
		Registration reg = new Registration();
		reg.setStudentName("Rohit");
		reg.setAddress("Hyderabad");
		reg.setPhoneNo("9090909090");
		reg.setCourseId(1);
		reg.setRegDate(LocalDate.now().plusDays(1));
		try {
			long regId =  rdao.registerCourse(reg);
			assertNotNull(regId);
		} catch (RegistrationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
