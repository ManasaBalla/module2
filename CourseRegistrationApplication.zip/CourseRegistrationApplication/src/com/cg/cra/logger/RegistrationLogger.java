package com.cg.cra.logger;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.cra.exceptions.RegistrationException;

public class RegistrationLogger {
	static Logger logger;
	public static Logger getLogger() throws RegistrationException {
		if(logger==null) {
			logger = Logger.getLogger("RegLogger");
			FileInputStream fin;
			try {
				fin = new FileInputStream("./resourse/log4j.properties");
			} catch (FileNotFoundException e) {
				throw new RegistrationException("Property file for logger "
						+ "not found"+e.getMessage());
			};
			PropertyConfigurator.configure(fin);
		}
		return logger;
	}

}
